## Setup

* `bz.zsh` contains the command line interface that powers Berzerk
* `config.zsh` is where secrets are stored

Once downloaded, run the following commands to properly move `bz-dev` 
and begin developing at Berzerk speed!

<add-later>