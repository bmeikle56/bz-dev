#!/bin/zsh

dev="<dev>"
repo=(
  "<repo1>"
  "<repo2>"
  "<repo3>"
)
backend_url="<backend_url>"
auth_token="<auth_token>"
github_token="<github_token>"