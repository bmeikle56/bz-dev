#!/bin/zsh

dev="<dev>"
repos=(
  "<repo1>"
  "<repo2>"
  "<repo3>"
)
auth_token="<auth_token>"
backend_url="<backend_url>"
github_token="<github_token>"