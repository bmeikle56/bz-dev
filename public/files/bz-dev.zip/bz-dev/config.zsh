#!/bin/zsh

dev="<dev>"
repo=(
  "<repo1>"
  "<repo2>"
  "<repo3>"
)
auth_token="<auth-token>"
github_token="<github_token>"